import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Badge } from "./ui/badge";
import { Calendar, DollarSign, Clock } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { useState } from "react";

interface Subscription {
  id: string;
  name: string;
  cost: number;
  billingCycle: 'monthly' | 'yearly';
  nextBilling: string;
  category: string;
  color?: string;
}

interface UpcomingPaymentsModalProps {
  subscriptions: Subscription[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

type SortBy = 'date' | 'amount' | 'category';

const categoryColors: Record<string, string> = {
  entertainment: 'bg-red-100 text-red-800',
  work: 'bg-blue-100 text-blue-800',
  fitness: 'bg-green-100 text-green-800',
  music: 'bg-purple-100 text-purple-800',
  gaming: 'bg-yellow-100 text-yellow-800',
  lifestyle: 'bg-pink-100 text-pink-800',
  education: 'bg-indigo-100 text-indigo-800'
};

export function UpcomingPaymentsModal({ subscriptions, open, onOpenChange }: UpcomingPaymentsModalProps) {
  const [sortBy, setSortBy] = useState<SortBy>('date');

  // Filter for upcoming payments (next 30 days)
  const now = new Date();
  const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  
  const upcomingPayments = subscriptions.filter(sub => {
    const nextBilling = new Date(sub.nextBilling);
    return nextBilling >= now && nextBilling <= thirtyDaysFromNow;
  });

  // Sort payments
  const sortedPayments = [...upcomingPayments].sort((a, b) => {
    switch (sortBy) {
      case 'date':
        return new Date(a.nextBilling).getTime() - new Date(b.nextBilling).getTime();
      case 'amount':
        return b.cost - a.cost; // Highest first
      case 'category':
        return a.category.localeCompare(b.category);
      default:
        return 0;
    }
  });

  const totalAmount = upcomingPayments.reduce((total, sub) => total + sub.cost, 0);

  const getDaysUntilDue = (nextBilling: string) => {
    const days = Math.ceil((new Date(nextBilling).getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return days;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-green-600" />
            Payments Due Next 30 Days
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 overflow-hidden flex flex-col">
          {/* Summary */}
          <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-4 mb-4 border border-green-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Amount Due</p>
                <p className="text-2xl font-bold text-gray-900">₹{totalAmount.toLocaleString('en-IN')}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600 mb-1">Payments</p>
                <p className="text-xl font-semibold text-gray-900">{upcomingPayments.length}</p>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium text-gray-900">Upcoming Payments</h3>
            <Select value={sortBy} onValueChange={(value: SortBy) => setSortBy(value)}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Date (Earliest First)</SelectItem>
                <SelectItem value="amount">Amount (High to Low)</SelectItem>
                <SelectItem value="category">Category</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Payment List */}
          <div className="flex-1 overflow-y-auto space-y-3 pr-2">
            {sortedPayments.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Clock className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No payments due in the next 30 days</p>
              </div>
            ) : (
              sortedPayments.map((payment) => {
                const daysUntil = getDaysUntilDue(payment.nextBilling);
                const isUrgent = daysUntil <= 7;
                
                return (
                  <div 
                    key={payment.id}
                    className={`p-4 rounded-lg border-2 transition-all hover:shadow-md ${
                      isUrgent 
                        ? 'bg-orange-50 border-orange-200' 
                        : 'bg-white border-gray-100'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-medium shadow-sm"
                          style={{ backgroundColor: payment.color || '#6B7280' }}
                        >
                          {payment.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{payment.name}</h4>
                          <Badge 
                            variant="secondary" 
                            className={`mt-1 ${categoryColors[payment.category.toLowerCase()] || 'bg-gray-100 text-gray-800'}`}
                          >
                            {payment.category}
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="flex items-center gap-1 font-semibold text-gray-900">
                          <DollarSign className="w-4 h-4" />
                          ₹{payment.cost.toLocaleString('en-IN')}
                        </div>
                        <div className={`text-sm mt-1 ${isUrgent ? 'text-orange-700 font-medium' : 'text-gray-500'}`}>
                          {daysUntil === 0 ? 'Due today' : 
                           daysUntil === 1 ? 'Due tomorrow' : 
                           `${daysUntil} days left`}
                        </div>
                        <div className="text-xs text-gray-500">
                          {new Date(payment.nextBilling).toLocaleDateString('en-IN', { 
                            day: 'numeric', 
                            month: 'short' 
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}