import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { TrendingUp, Calendar, Crown, AlertCircle } from "lucide-react";
import { Badge } from "./ui/badge";
import { useState } from "react";
import { UpcomingPaymentsModal } from "./upcoming-payments-modal";
import { UrgentAlertsModal } from "./urgent-alerts-modal";

interface Subscription {
  id: string;
  name: string;
  cost: number;
  billingCycle: 'monthly' | 'yearly';
  nextBilling: string;
  category: string;
  color?: string;
}

interface KeyMetricsProps {
  subscriptions: Subscription[];
}

export function KeyMetrics({ subscriptions }: KeyMetricsProps) {
  const [upcomingModalOpen, setUpcomingModalOpen] = useState(false);
  const [urgentModalOpen, setUrgentModalOpen] = useState(false);

  // Calculate total monthly cost
  const totalMonthlyCost = subscriptions.reduce((total, sub) => {
    const monthlyCost = sub.billingCycle === 'yearly' ? sub.cost / 12 : sub.cost;
    return total + monthlyCost;
  }, 0);

  // Find highest subscription
  const highestSubscription = subscriptions.reduce((highest, current) => {
    const currentMonthlyCost = current.billingCycle === 'yearly' ? current.cost / 12 : current.cost;
    const highestMonthlyCost = highest ? (highest.billingCycle === 'yearly' ? highest.cost / 12 : highest.cost) : 0;
    return currentMonthlyCost > highestMonthlyCost ? current : highest;
  }, null as Subscription | null);

  // Calculate upcoming payments (next 30 days)
  const now = new Date();
  const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  
  const upcomingPayments = subscriptions.filter(sub => {
    const nextBilling = new Date(sub.nextBilling);
    return nextBilling >= now && nextBilling <= thirtyDaysFromNow;
  });

  const upcomingTotal = upcomingPayments.reduce((total, sub) => total + sub.cost, 0);

  // Check for payments due in next 7 days
  const sevenDaysFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  const urgentPayments = subscriptions.filter(sub => {
    const nextBilling = new Date(sub.nextBilling);
    return nextBilling >= now && nextBilling <= sevenDaysFromNow;
  });

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
        {/* Total Monthly Spend Card */}
        <Card className="bg-gradient-to-br from-blue-50 via-blue-50 to-blue-100 border-blue-200 shadow-lg shadow-blue-100/50 hover:shadow-xl hover:shadow-blue-100/60 transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-semibold text-blue-800">Total Monthly Spend</CardTitle>
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center shadow-sm">
              <TrendingUp className="h-4 w-4 text-white" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-900 mb-1">₹{Math.round(totalMonthlyCost).toLocaleString('en-IN')}</div>
            <p className="text-sm text-blue-700 font-medium">
              Across {subscriptions.length} subscription{subscriptions.length !== 1 ? 's' : ''}
            </p>
          </CardContent>
        </Card>

        {/* Upcoming Payments Card - Clickable */}
        <Card 
          className="bg-gradient-to-br from-green-50 via-green-50 to-green-100 border-green-200 shadow-lg shadow-green-100/50 hover:shadow-xl hover:shadow-green-100/60 transition-all duration-300 cursor-pointer group"
          onClick={() => setUpcomingModalOpen(true)}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-semibold text-green-800 group-hover:text-green-900 transition-colors">
              Upcoming Payments
            </CardTitle>
            <div className="w-8 h-8 rounded-lg bg-green-600 flex items-center justify-center shadow-sm group-hover:bg-green-700 transition-colors">
              <Calendar className="h-4 w-4 text-white" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-900 mb-1">₹{upcomingTotal.toLocaleString('en-IN')}</div>
            <p className="text-sm text-green-700 font-medium">
              {upcomingPayments.length} payment{upcomingPayments.length !== 1 ? 's' : ''} in next 30 days
            </p>
            <p className="text-xs text-green-600 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
              Click to view details →
            </p>
          </CardContent>
        </Card>

        {/* Highest Subscription Card */}
        <Card className="bg-gradient-to-br from-purple-50 via-purple-50 to-purple-100 border-purple-200 shadow-lg shadow-purple-100/50 hover:shadow-xl hover:shadow-purple-100/60 transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-semibold text-purple-800">Highest Subscription</CardTitle>
            <div className="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center shadow-sm">
              <Crown className="h-4 w-4 text-white" />
            </div>
          </CardHeader>
          <CardContent>
            {highestSubscription ? (
              <>
                <div className="text-xl font-bold text-purple-900 truncate mb-1">
                  {highestSubscription.name}
                </div>
                <p className="text-sm text-purple-700 font-medium">
                  ₹{Math.round(highestSubscription.billingCycle === 'yearly' ? 
                    highestSubscription.cost / 12 : 
                    highestSubscription.cost
                  ).toLocaleString('en-IN')}/month
                </p>
              </>
            ) : (
              <div className="text-lg font-medium text-purple-700">No subscriptions yet</div>
            )}
          </CardContent>
        </Card>

        {/* Urgent Alerts Card - Clickable */}
        <Card 
          className={`bg-gradient-to-br shadow-lg hover:shadow-xl transition-all duration-300 ${
            urgentPayments.length > 0 
              ? 'from-orange-50 via-orange-50 to-orange-100 border-orange-200 shadow-orange-100/50 hover:shadow-orange-100/60 cursor-pointer group' 
              : 'from-gray-50 via-gray-50 to-gray-100 border-gray-200 shadow-gray-100/50 hover:shadow-gray-100/60'
          }`}
          onClick={() => urgentPayments.length > 0 && setUrgentModalOpen(true)}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className={`text-sm font-semibold ${
              urgentPayments.length > 0 
                ? 'text-orange-800 group-hover:text-orange-900' 
                : 'text-gray-800'
            } transition-colors`}>
              Urgent Alerts
            </CardTitle>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shadow-sm transition-colors ${
              urgentPayments.length > 0 
                ? 'bg-orange-600 group-hover:bg-orange-700' 
                : 'bg-gray-500'
            }`}>
              <AlertCircle className="h-4 w-4 text-white" />
            </div>
          </CardHeader>
          <CardContent>
            {urgentPayments.length > 0 ? (
              <>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="destructive" className="bg-orange-600 font-semibold">
                    {urgentPayments.length} due soon
                  </Badge>
                </div>
                <p className="text-sm text-orange-700 font-medium mb-2">
                  Payments due in next 7 days
                </p>
                <p className="text-xs text-orange-600 opacity-0 group-hover:opacity-100 transition-opacity">
                  Click to view details →
                </p>
              </>
            ) : (
              <>
                <div className="text-lg font-bold text-gray-700 mb-1">All Clear</div>
                <p className="text-sm text-gray-600 font-medium">
                  No urgent payments due
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Modals */}
      <UpcomingPaymentsModal 
        subscriptions={subscriptions}
        open={upcomingModalOpen}
        onOpenChange={setUpcomingModalOpen}
      />
      
      <UrgentAlertsModal 
        subscriptions={subscriptions}
        open={urgentModalOpen}
        onOpenChange={setUrgentModalOpen}
      />
    </>
  );
}