import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Calendar, DollarSign, Trash2 } from "lucide-react";

interface Subscription {
  id: string;
  name: string;
  cost: number;
  billingCycle: 'monthly' | 'yearly';
  nextBilling: string;
  category: string;
  logo?: string;
  color?: string;
}

interface SubscriptionCardProps {
  subscription: Subscription;
  onDelete: (id: string) => void;
}

const categoryColors: Record<string, string> = {
  entertainment: 'bg-red-100 text-red-800',
  work: 'bg-blue-100 text-blue-800',
  fitness: 'bg-green-100 text-green-800',
  music: 'bg-purple-100 text-purple-800',
  gaming: 'bg-yellow-100 text-yellow-800',
  lifestyle: 'bg-pink-100 text-pink-800',
  education: 'bg-indigo-100 text-indigo-800'
};

export function SubscriptionCard({ subscription, onDelete }: SubscriptionCardProps) {
  const monthlyCost = subscription.billingCycle === 'yearly' ? subscription.cost / 12 : subscription.cost;
  const nextBillingDate = new Date(subscription.nextBilling).toLocaleDateString('en-IN', { 
    day: 'numeric', 
    month: 'short', 
    year: 'numeric' 
  });

  return (
    <Card className="p-4 sm:p-6 hover:shadow-lg hover:shadow-gray-100/60 transition-all duration-300 border border-gray-100 bg-white/80 backdrop-blur-sm group">
      {/* Desktop Layout */}
      <div className="hidden sm:flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div 
            className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-semibold shadow-lg transition-transform group-hover:scale-105"
            style={{ backgroundColor: subscription.color || '#6B7280' }}
          >
            {subscription.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <h3 className="font-semibold text-gray-900 text-lg mb-1">{subscription.name}</h3>
            <div className="flex items-center gap-2">
              <Badge 
                variant="secondary" 
                className={`font-medium ${categoryColors[subscription.category.toLowerCase()] || 'bg-gray-100 text-gray-800'}`}
              >
                {subscription.category}
              </Badge>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="text-right">
            <div className="flex items-center gap-1 text-xl font-bold text-gray-900 mb-1">
              <DollarSign className="w-5 h-5" />
              ₹{subscription.cost.toLocaleString('en-IN')}
            </div>
            <div className="text-sm font-medium text-gray-600">
              {subscription.billingCycle} (₹{monthlyCost.toFixed(0)}/mo)
            </div>
          </div>
          
          <div className="text-right">
            <div className="flex items-center gap-1 text-sm font-medium text-gray-700 mb-1">
              <Calendar className="w-4 h-4" />
              {nextBillingDate}
            </div>
            <div className="text-xs text-gray-500">Next billing</div>
          </div>
          
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => onDelete(subscription.id)}
            className="text-red-500 hover:text-red-700 hover:bg-red-50 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Mobile Layout */}
      <div className="sm:hidden space-y-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div 
              className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-semibold shadow-md flex-shrink-0"
              style={{ backgroundColor: subscription.color || '#6B7280' }}
            >
              {subscription.name.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="font-semibold text-gray-900 truncate mb-1">{subscription.name}</h3>
              <Badge 
                variant="secondary" 
                className={`text-xs font-medium ${categoryColors[subscription.category.toLowerCase()] || 'bg-gray-100 text-gray-800'}`}
              >
                {subscription.category}
              </Badge>
            </div>
          </div>
          
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => onDelete(subscription.id)}
            className="text-red-500 hover:text-red-700 hover:bg-red-50 transition-colors flex-shrink-0"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex justify-between items-end pt-2 border-t border-gray-100">
          <div>
            <div className="flex items-center gap-1 text-lg font-bold text-gray-900 mb-1">
              <DollarSign className="w-4 h-4" />
              ₹{subscription.cost.toLocaleString('en-IN')}
            </div>
            <div className="text-xs font-medium text-gray-600">
              {subscription.billingCycle} (₹{monthlyCost.toFixed(0)}/mo)
            </div>
          </div>
          
          <div className="text-right">
            <div className="text-sm font-medium text-gray-700 mb-1">
              {nextBillingDate}
            </div>
            <div className="text-xs text-gray-500 flex items-center gap-1 justify-end">
              <Calendar className="w-3 h-3" />
              Next billing
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}