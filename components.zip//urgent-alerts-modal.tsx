import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { AlertCircle, DollarSign, ExternalLink, CheckCircle } from "lucide-react";

interface Subscription {
  id: string;
  name: string;
  cost: number;
  billingCycle: 'monthly' | 'yearly';
  nextBilling: string;
  category: string;
  color?: string;
}

interface UrgentAlertsModalProps {
  subscriptions: Subscription[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const categoryColors: Record<string, string> = {
  entertainment: 'bg-red-100 text-red-800',
  work: 'bg-blue-100 text-blue-800',
  fitness: 'bg-green-100 text-green-800',
  music: 'bg-purple-100 text-purple-800',
  gaming: 'bg-yellow-100 text-yellow-800',
  lifestyle: 'bg-pink-100 text-pink-800',
  education: 'bg-indigo-100 text-indigo-800'
};

export function UrgentAlertsModal({ subscriptions, open, onOpenChange }: UrgentAlertsModalProps) {
  // Filter for urgent payments (next 7 days)
  const now = new Date();
  const sevenDaysFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  
  const urgentPayments = subscriptions.filter(sub => {
    const nextBilling = new Date(sub.nextBilling);
    return nextBilling >= now && nextBilling <= sevenDaysFromNow;
  }).sort((a, b) => new Date(a.nextBilling).getTime() - new Date(b.nextBilling).getTime());

  const totalUrgentAmount = urgentPayments.reduce((total, sub) => total + sub.cost, 0);

  const getDaysUntilDue = (nextBilling: string) => {
    const days = Math.ceil((new Date(nextBilling).getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return days;
  };

  const getUrgencyLevel = (days: number) => {
    if (days <= 1) return 'critical';
    if (days <= 3) return 'high';
    return 'medium';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-orange-600" />
            Urgent Payment Alerts
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 overflow-hidden flex flex-col">
          {urgentPayments.length === 0 ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">All Clear!</h3>
                <p className="text-gray-600 mb-4">No urgent payments due in the next 7 days.</p>
                <p className="text-sm text-gray-500">Check back regularly to stay on top of your subscriptions.</p>
              </div>
            </div>
          ) : (
            <>
              {/* Summary */}
              <div className="bg-gradient-to-r from-orange-50 to-red-50 rounded-lg p-4 mb-4 border-2 border-orange-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-orange-800 mb-1">Total Urgent Amount</p>
                    <p className="text-2xl font-bold text-orange-900">₹{totalUrgentAmount.toLocaleString('en-IN')}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-orange-800 mb-1">Urgent Payments</p>
                    <p className="text-xl font-semibold text-orange-900">{urgentPayments.length}</p>
                  </div>
                </div>
                <div className="mt-3 p-2 bg-orange-100 rounded text-sm text-orange-800">
                  <strong>Action Required:</strong> These payments are due within the next 7 days. Review them to avoid any service interruptions.
                </div>
              </div>

              {/* Payment List */}
              <div className="flex-1 overflow-y-auto space-y-3 pr-2">
                {urgentPayments.map((payment) => {
                  const daysUntil = getDaysUntilDue(payment.nextBilling);
                  const urgencyLevel = getUrgencyLevel(daysUntil);
                  
                  const urgencyColors = {
                    critical: 'bg-red-50 border-red-300 shadow-red-100',
                    high: 'bg-orange-50 border-orange-300 shadow-orange-100',
                    medium: 'bg-yellow-50 border-yellow-300 shadow-yellow-100'
                  };

                  const urgencyBadges = {
                    critical: 'bg-red-600 text-white',
                    high: 'bg-orange-600 text-white', 
                    medium: 'bg-yellow-600 text-white'
                  };
                  
                  return (
                    <div 
                      key={payment.id}
                      className={`p-4 rounded-lg border-2 transition-all hover:shadow-lg ${urgencyColors[urgencyLevel]} shadow-md`}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div 
                            className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-medium shadow-md"
                            style={{ backgroundColor: payment.color || '#6B7280' }}
                          >
                            {payment.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-1">{payment.name}</h4>
                            <div className="flex items-center gap-2">
                              <Badge 
                                variant="secondary" 
                                className={categoryColors[payment.category.toLowerCase()] || 'bg-gray-100 text-gray-800'}
                              >
                                {payment.category}
                              </Badge>
                              <Badge className={urgencyBadges[urgencyLevel]}>
                                {urgencyLevel === 'critical' ? 'CRITICAL' : 
                                 urgencyLevel === 'high' ? 'HIGH PRIORITY' : 'URGENT'}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className="flex items-center gap-1 text-lg font-bold text-gray-900 mb-1">
                            <DollarSign className="w-4 h-4" />
                            ₹{payment.cost.toLocaleString('en-IN')}
                          </div>
                          <div className="text-sm text-gray-600">
                            {payment.billingCycle} payment
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-gray-200">
                        <div className="text-sm">
                          <span className="font-medium text-gray-700">Due: </span>
                          <span className={`font-semibold ${
                            daysUntil <= 1 ? 'text-red-700' : 
                            daysUntil <= 3 ? 'text-orange-700' : 'text-yellow-700'
                          }`}>
                            {daysUntil === 0 ? 'Today' : 
                             daysUntil === 1 ? 'Tomorrow' : 
                             `${daysUntil} days`}
                          </span>
                          <span className="text-gray-500 ml-2">
                            ({new Date(payment.nextBilling).toLocaleDateString('en-IN', { 
                              weekday: 'short',
                              day: 'numeric', 
                              month: 'short' 
                            })})
                          </span>
                        </div>

                        <Button 
                          variant="outline" 
                          size="sm"
                          className="text-blue-600 hover:text-blue-700 border-blue-200 hover:border-blue-300"
                        >
                          <ExternalLink className="w-3 h-3 mr-1" />
                          Manage
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Action Footer */}
              <div className="mt-4 p-3 bg-gray-50 rounded-lg border">
                <p className="text-sm text-gray-600 mb-2">
                  <strong>Pro tip:</strong> Set calendar reminders or enable auto-pay to avoid missing these payments.
                </p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                  onClick={() => onOpenChange(false)}
                >
                  Mark All as Reviewed
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}