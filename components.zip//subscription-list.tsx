import { useState } from 'react';
import { SubscriptionCard } from './subscription-card';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Button } from './ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from './ui/sheet';
import { Search, Filter, SortAsc, Settings2 } from 'lucide-react';

interface Subscription {
  id: string;
  name: string;
  cost: number;
  billingCycle: 'monthly' | 'yearly';
  nextBilling: string;
  category: string;
  color?: string;
}

interface SubscriptionListProps {
  subscriptions: Subscription[];
  onDeleteSubscription: (id: string) => void;
}

type SortBy = 'name' | 'cost' | 'nextBilling' | 'category';
type FilterBy = 'all' | 'entertainment' | 'work' | 'fitness' | 'music' | 'gaming' | 'lifestyle' | 'education';

export function SubscriptionList({ subscriptions, onDeleteSubscription }: SubscriptionListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<SortBy>('nextBilling');
  const [filterBy, setFilterBy] = useState<FilterBy>('all');

  // Filter subscriptions
  const filteredSubscriptions = subscriptions.filter(subscription => {
    const matchesSearch = subscription.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterBy === 'all' || subscription.category.toLowerCase() === filterBy;
    return matchesSearch && matchesCategory;
  });

  // Sort subscriptions
  const sortedSubscriptions = [...filteredSubscriptions].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'cost':
        const aMonthlyCost = a.billingCycle === 'yearly' ? a.cost / 12 : a.cost;
        const bMonthlyCost = b.billingCycle === 'yearly' ? b.cost / 12 : b.cost;
        return bMonthlyCost - aMonthlyCost; // Highest first
      case 'nextBilling':
        return new Date(a.nextBilling).getTime() - new Date(b.nextBilling).getTime();
      case 'category':
        return a.category.localeCompare(b.category);
      default:
        return 0;
    }
  });

  const categories = Array.from(new Set(subscriptions.map(sub => sub.category.toLowerCase())));

  return (
    <div className="space-y-6">
      {/* Desktop Filters */}
      <div className="hidden lg:flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search subscriptions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-white/80 backdrop-blur-sm border-gray-200 shadow-sm focus:shadow-md transition-shadow"
          />
        </div>
        
        <div className="flex gap-3">
          <Select value={filterBy} onValueChange={(value: FilterBy) => setFilterBy(value)}>
            <SelectTrigger className="w-[180px] bg-white/80 backdrop-blur-sm border-gray-200 shadow-sm">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(category => (
                <SelectItem key={category} value={category}>
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={sortBy} onValueChange={(value: SortBy) => setSortBy(value)}>
            <SelectTrigger className="w-[180px] bg-white/80 backdrop-blur-sm border-gray-200 shadow-sm">
              <SortAsc className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="nextBilling">Next Billing</SelectItem>
              <SelectItem value="cost">Cost (High to Low)</SelectItem>
              <SelectItem value="name">Name (A-Z)</SelectItem>
              <SelectItem value="category">Category</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Mobile Filters */}
      <div className="lg:hidden space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search subscriptions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-white/80 backdrop-blur-sm border-gray-200 shadow-sm"
          />
        </div>
        
        <div className="flex gap-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" className="flex-1 bg-white/80 backdrop-blur-sm border-gray-200 shadow-sm">
                <Settings2 className="h-4 w-4 mr-2" />
                Filters & Sort
                {(filterBy !== 'all' || sortBy !== 'nextBilling') && (
                  <span className="ml-2 w-2 h-2 bg-blue-500 rounded-full"></span>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent side="bottom" className="h-[400px]">
              <SheetHeader className="mb-6">
                <SheetTitle>Filter & Sort Options</SheetTitle>
                <SheetDescription>
                  Customize how your subscriptions are displayed and organized.
                </SheetDescription>
              </SheetHeader>
              <div className="space-y-6">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-3 block">Filter by Category</label>
                  <Select value={filterBy} onValueChange={(value: FilterBy) => setFilterBy(value)}>
                    <SelectTrigger className="w-full">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Filter by category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories.map(category => (
                        <SelectItem key={category} value={category}>
                          {category.charAt(0).toUpperCase() + category.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-3 block">Sort by</label>
                  <Select value={sortBy} onValueChange={(value: SortBy) => setSortBy(value)}>
                    <SelectTrigger className="w-full">
                      <SortAsc className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nextBilling">Next Billing</SelectItem>
                      <SelectItem value="cost">Cost (High to Low)</SelectItem>
                      <SelectItem value="name">Name (A-Z)</SelectItem>
                      <SelectItem value="category">Category</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {(filterBy !== 'all' || sortBy !== 'nextBilling') && (
                  <Button 
                    variant="outline" 
                    onClick={() => { setFilterBy('all'); setSortBy('nextBilling'); }}
                    className="w-full"
                  >
                    Clear All Filters
                  </Button>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {sortedSubscriptions.length === 0 ? (
        <div className="text-center py-16 px-4">
          <div className="w-16 h-16 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
            <Search className="w-8 h-8 text-gray-400" />
          </div>
          <div className="text-lg font-medium text-gray-700 mb-2">
            {searchTerm || filterBy !== 'all' 
              ? 'No subscriptions match your filters'
              : 'No subscriptions added yet'
            }
          </div>
          <p className="text-sm text-gray-500 mb-6 max-w-md mx-auto">
            {searchTerm || filterBy !== 'all' 
              ? 'Try adjusting your search terms or filters to find what you\'re looking for.'
              : 'Start by adding your first subscription to get a clear overview of your monthly spending.'
            }
          </p>
          {(searchTerm || filterBy !== 'all') && (
            <Button 
              variant="outline" 
              onClick={() => { setSearchTerm(''); setFilterBy('all'); }}
              className="bg-white/80 backdrop-blur-sm"
            >
              Clear filters
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-1">
                Your Subscriptions
              </h2>
              <p className="text-sm text-gray-600">
                {sortedSubscriptions.length} subscription{sortedSubscriptions.length !== 1 ? 's' : ''} found
                {(searchTerm || filterBy !== 'all') && (
                  <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                    Filtered
                  </span>
                )}
              </p>
            </div>
          </div>
          
          <div className="space-y-4">
            {sortedSubscriptions.map((subscription) => (
              <SubscriptionCard
                key={subscription.id}
                subscription={subscription}
                onDelete={onDeleteSubscription}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}